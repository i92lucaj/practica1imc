/*********************************************************************
* File  : MultilayerPerceptron.cpp
* Date  : 2020
*********************************************************************/

#include "MultilayerPerceptron.h"

#include "util.h"


#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>  // To establish the seed srand() and generate pseudorandom numbers rand()
#include <limits>
#include <math.h>


using namespace imc;
using namespace std;
using namespace util;

// ------------------------------
// Constructor: Default values for all the parameters
MultilayerPerceptron::MultilayerPerceptron()
{

	layers = NULL;
	decrementFactor = 1;
	nOfLayers=2;
	eta=0.1;
	mu=0.9;
	validationRatio=0;

}

// ------------------------------
// Allocate memory for the data structures
// nl is the number of layers and npl is a vetor containing the number of neurons in every layer
// Give values to Layer* layers
int MultilayerPerceptron::initialize(int nl, int npl[]) {
	
	if(nl>2)
	{
		nOfLayers=nl;
		layers=new Layer[nl];


		for(int i=0;i<nl;i++)
		{

			layers[i].nOfNeurons=npl[i];
			layers[i].neurons=new Neuron[npl[i]];


			for(int j=0;j<npl[i];j++)
			{

				Neuron *newNeuron= new Neuron;
				layers[i].neurons[j]=*newNeuron;

				if(i>0)
				{

					layers[i].neurons[j].w = new double[layers[i-1].nOfNeurons+1];
					layers[i].neurons[j].wCopy = new double[layers[i-1].nOfNeurons+1];
					layers[i].neurons[j].deltaW = new double[layers[i-1].nOfNeurons+1];
					layers[i].neurons[j].lastDeltaW = new double[layers[i-1].nOfNeurons+1];
					
				}
			}
		}
		return 1;
	}
	else
	{
		std::cout<<"Número de capas inválido"<<std::endl;
		return 0;
	}
}


// ------------------------------
// DESTRUCTOR: free memory
MultilayerPerceptron::~MultilayerPerceptron() {
	freeMemory();
}


// ------------------------------
// Free memory for the data structures
void MultilayerPerceptron::freeMemory() {

	for(int i=0;i<nOfLayers;i++)
	{
		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
			if(i > 0)
			{
				delete layers[i].neurons[j].deltaW;
				delete layers[i].neurons[j].lastDeltaW;
				delete layers[i].neurons[j].w;
				delete layers[i].neurons[j].wCopy;
			}
		}
		delete[] layers[i].neurons;
			
	}
	delete[] layers;
}

// ------------------------------
// Feel all the weights (w) with random numbers between -1 and +1
void MultilayerPerceptron::randomWeights() {

	for(int i=1;i<nOfLayers;i++)
	{

		for(int j=0;j<layers[i].nOfNeurons;j++)
		{

			for(int k=0;k<layers[i-1].nOfNeurons+1;k++)
			{

				layers[i].neurons[j].w[k]=pow(-1,rand())*static_cast <float> (rand()) / (static_cast <float> (RAND_MAX));
			}
		}
	}

}

// ------------------------------
// Feed the input neurons of the network with a vector passed as an argument
void MultilayerPerceptron::feedInputs(double* input) {


	for(int i=0;i<layers[0].nOfNeurons;i++)
	{
		layers[0].neurons[i].out=input[i];
	}
}

// ------------------------------
// Get the outputs predicted by the network (out vector the output layer) and save them in the vector passed as an argument
void MultilayerPerceptron::getOutputs(double* output)
{
	for(int i=0; i < layers[nOfLayers-1].nOfNeurons; i++)
	{
		output[i] = layers[nOfLayers-1].neurons[i].out;
	}
}

// ------------------------------
// Make a copy of all the weights (copy w in wCopy)
void MultilayerPerceptron::copyWeights() {

	for(int i=1;i<nOfLayers;i++)
	{


		for(int j=0;j<layers[i].nOfNeurons;j++)
		{

			for(int k=0;k<layers[i-1].nOfNeurons+1;k++)
			{
				layers[i].neurons[j].wCopy[k]=layers[i].neurons[j].w[k];
			}
		}
	}

}

// ------------------------------
// Restore a copy of all the weights (copy wCopy in w)
void MultilayerPerceptron::restoreWeights() {

	for(int i=1;i<nOfLayers;i++)
	{
		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
			for(int k=0;k<layers[i-1].nOfNeurons+1;k++)
			{
				layers[i].neurons[j].w[k]=layers[i].neurons[j].wCopy[k];
			}
		}
	}

}

// ------------------------------
// Calculate and propagate the outputs of the neurons, from the first layer until the last one -->-->
void MultilayerPerceptron::forwardPropagate() {
	
	for(int i=1;i<nOfLayers;i++)
	{


		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
		
			double sigmoid=layers[i].neurons[j].w[0];

			for(int k=0;k<layers[i-1].nOfNeurons+1;k++)
			{


			   sigmoid+=layers[i].neurons[j].w[k+1]*layers[i-1].neurons[k].out;
			}
			layers[i].neurons[j].out=(double)1/(1+ exp(-1*sigmoid));
		}
	}

}

// ------------------------------
// Obtain the output error (MSE) of the out vector of the output layer wrt a target vector and return it
double MultilayerPerceptron::obtainError(double* target) {
	
	double error=0.0;

	for(int i=0;i<layers[nOfLayers-1].nOfNeurons;i++)
	
	{
		error+=pow(target[i]-layers[nOfLayers-1].neurons[i].out,2);
	}
	error=(double)error/layers[nOfLayers-1].nOfNeurons;

	return error;



}

/* XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
	for(int i = 0;i<;i++)
	{
		for(int o = 0;o<;o++)
		{
			for(int u = 0;u<;u++)
			{
				
			}
		}
	}

*/

// ------------------------------
// Backpropagate the output error wrt a vector passed as an argument, from the last layer to the first one <--<--
void MultilayerPerceptron::backpropagateError(double* target) {


    for(int i=0;i<layers[nOfLayers-1].nOfNeurons;i++)
	{
    	double out=layers[nOfLayers-1].neurons[i].out;
        layers[nOfLayers-1].neurons[i].delta=-1*(target[i]-out)*(1-out)*out;
    }
    for(int i=nOfLayers-2;i>=1;i--){
    	for(int j=0;j<layers[i].nOfNeurons;j++)
		{
    		double sum=0.0;
    		for(int k=0;k<layers[i+1].nOfNeurons;k++)
			{
    			sum+=layers[i+1].neurons[k].delta*layers[i+1].neurons[k].w[j+1];
    		}
    		double out=layers[i].neurons[j].out;
    		layers[i].neurons[j].delta=sum*out*(1-out);
    	}
    }


}


// ------------------------------
// Accumulate the changes produced by one pattern and save them in deltaW
void MultilayerPerceptron::accumulateChange() {
	for(int i=1;i<nOfLayers;i++)
	{


		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
    		for(int k=1;k<layers[i-1].nOfNeurons+1;k++)
			
			{
    			layers[i].neurons[j].lastDeltaW[k]=layers[i].neurons[j].deltaW[k];
    			layers[i].neurons[j].deltaW[k]+= layers[i].neurons[j].delta * layers[i-1].neurons[k-1].out;

    		}
			layers[i].neurons[j].lastDeltaW[0]=layers[i].neurons[j].deltaW[0];
    		layers[i].neurons[j].deltaW[0]+=layers[i].neurons[j].delta;
		}
	}



}

// ------------------------------
// Update the network weights, from the first layer to the last one
void MultilayerPerceptron::weightAdjustment() {

	double Eta=eta;


	for(int i=1;i<nOfLayers;i++)
	{
		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
    		for(int k=1;k<layers[i-1].nOfNeurons+1;k++)
			{


    			layers[i].neurons[j].w[k]=layers[i].neurons[j].w[k]-Eta*layers[i].neurons[j].deltaW[k]-mu*(Eta*layers[i].neurons[j].lastDeltaW[k]);
    		}


			layers[i].neurons[j].w[0]=layers[i].neurons[j].w[0]-Eta*layers[i].neurons[j].deltaW[0]-mu*(Eta*layers[i].neurons[j].lastDeltaW[0]);    		
		}

		Eta=pow(decrementFactor,-(nOfLayers-i))*Eta;
	}
}

// ------------------------------
// Print the network, i.e. all the weight matrices
void MultilayerPerceptron::printNetwork() {

	//std::cout<<"IMPORTANTE: "<<std::endl;
	//std::cout<<"Numero de capas: "<<nOfLayers<<std::endl;


	for(int i=1;i<nOfLayers;i++)
	{
		std::cout<<"Capa "<<i<<std::endl<<"========"<<std::endl;


		for(int j=0;j<layers[i].nOfNeurons;j++)
		{
			std::cout<<"Neurona "<<j<<" de la capa "<<i<<" : ";
    		for(int k=0;k<layers[i-1].nOfNeurons+1;k++)
			{

    			std::cout<<layers[i].neurons[j].w[k]<<"\t";
    		}
    		std::cout<<std::endl;
		}
	}

}

// ------------------------------
// Perform an epoch: forward propagate the inputs, backpropagate the error and adjust the weights
// input is the input vector of the pattern and target is the desired output vector of the pattern
void MultilayerPerceptron::performEpochOnline(double* input, double* target) {

	for(int i=1; i < this->nOfLayers; i++)
	{
		for(int j=0; j < this->layers[i].nOfNeurons; j++)
		{
			for(int k=0; k < this->layers[i-1].nOfNeurons + 1; k++)
			{
				this->layers[i].neurons[j].deltaW[k] = 0.0;
			}
		}
	}


	
	feedInputs(input);
	//std::cout<<"1 - Entradas alimentadas"<<std::endl;
	forwardPropagate();
	//std::cout<<"2 - Propagación hacia adelante"<<std::endl;
	backpropagateError(target);
	//std::cout<<"3 - BackPropagation"<<std::endl;
	accumulateChange();
	//std::cout<<"4 - Se acumula el cambio"<<std::endl;
	weightAdjustment();
	//std::cout<<"5 - Se ajustan los pesos"<<std::endl;


}

// ------------------------------
// Read a dataset from a file name and return it
Dataset* MultilayerPerceptron::readData(const char *fileName) {
	ifstream myFile(fileName);    // Create an input stream

    if (!myFile.is_open()) {
       cout << "ERROR: I cannot open the file " << fileName << endl;
       return NULL;
    }

	Dataset * dataset = new Dataset;
	if(dataset==NULL)
		return NULL;

	string line;
	int i,j;


	if( myFile.good()) {
		getline(myFile,line);   // Read a line
		istringstream iss(line);
		iss >> dataset->nOfInputs;
		iss >> dataset->nOfOutputs;
		iss >> dataset->nOfPatterns;
	}
	dataset->inputs = new double*[dataset->nOfPatterns];
	dataset->outputs = new double*[dataset->nOfPatterns];

	for(i=0; i<dataset->nOfPatterns; i++){
		dataset->inputs[i] = new double[dataset->nOfInputs];
		dataset->outputs[i] = new double[dataset->nOfOutputs];
	}

	i=0;
	while ( myFile.good()) {
		getline(myFile,line);   // Read a line
		if (! line.empty()) {
			istringstream iss(line);
			for(j=0; j< dataset->nOfInputs; j++){
				double value;
				iss >> value;
				if(!iss)
					return NULL;
				dataset->inputs[i][j] = value;
			}
			for(j=0; j< dataset->nOfOutputs; j++){
				double value;
				iss >> value;
				if(!iss)
					return NULL;
				dataset->outputs[i][j] = value;
			}
			i++;
		}
	}

	myFile.close();

	std::cout<<"Inputs : "<<dataset->nOfInputs<<std::endl;
	std::cout<<"Outputs : "<<dataset->nOfOutputs<<std::endl;
	std::cout<<"Patterns : "<<dataset->nOfPatterns<<std::endl;

	return dataset;


	
}

// ------------------------------
// Perform an online training for a specific trainDataset
void MultilayerPerceptron::trainOnline(Dataset* trainDataset) {
	int i;
	for(i=0; i<trainDataset->nOfPatterns; i++){
		performEpochOnline(trainDataset->inputs[i], trainDataset->outputs[i]);
	}
}

// ------------------------------
// Test the network with a dataset and return the MSE
double MultilayerPerceptron::test(Dataset* testDataset) {
	double mse = 0;

	for(int i = 0;i<testDataset->nOfPatterns;i++)
	{
		feedInputs(testDataset->inputs[i]);
		forwardPropagate();
		mse+=obtainError(testDataset->outputs[i]);
	}
	mse/=testDataset->nOfPatterns;
	
	return mse;
}


// Optional - KAGGLE
// Test the network with a dataset and return the MSE
// Your have to use the format from Kaggle: two columns (Id y predictied)
void MultilayerPerceptron::predict(Dataset* pDatosTest)
{
	int i;
	int j;
	int numSalidas = layers[nOfLayers-1].nOfNeurons;
	double * obtained = new double[numSalidas];
	
	cout << "Id,Predicted" << endl;
	
	for (i=0; i<pDatosTest->nOfPatterns; i++){

		feedInputs(pDatosTest->inputs[i]);
		forwardPropagate();
		getOutputs(obtained);
		
		cout << i;

		for (j = 0; j < numSalidas; j++)
			cout << "," << obtained[j];
		cout << endl;

	}
}

// ------------------------------
// Run the traning algorithm for a given number of epochs, using trainDataset
// Once finished, check the performance of the network in testDataset
// Both training and test MSEs should be obtained and stored in errorTrain and errorTest
void MultilayerPerceptron::runOnlineBackPropagation(Dataset * trainDataset, Dataset * pDatosTest, int maxiter, double *errorTrain, double *errorTest)
{
	int countTrain = 0;

	// Random assignment of weights (starting point)
	randomWeights();

	
	int iterWithoutImproving;

	double minTrainError = 0.0;
	double testError = 0.0;
	
	double validationError = 0.0;	
	double minValidationError = 0.0;
	double iterWithoutImprovingValidation = 0.0;
	Dataset *pDatosValidation=NULL;

	// Generate validation data
	if(validationRatio > 0 && validationRatio < 1){
		
		int* choosenVector=integerRandomVectoWithoutRepeating(0,trainDataset->nOfPatterns-1,round(trainDataset->nOfPatterns*validationRatio));
		
		

		pDatosValidation=new Dataset;
		pDatosValidation->nOfPatterns = round(trainDataset->nOfPatterns*validationRatio);
		pDatosValidation->nOfInputs = trainDataset->nOfInputs;
		pDatosValidation->nOfOutputs = trainDataset->nOfOutputs;


		//Reservamos memoria para las entradas de test
		pDatosValidation->inputs=new double*[pDatosValidation->nOfPatterns];
		
		for(int i = 0; i < pDatosValidation->nOfPatterns; i++)
		{
			pDatosValidation->inputs[i] = new double[pDatosValidation->nOfInputs];
		}
			
		
		
		//Reservamos memoria para las salidas de test
		pDatosValidation->outputs=new double*[pDatosValidation->nOfPatterns];
		
		for(int i = 0; i < pDatosValidation->nOfPatterns; i++)
		{
			pDatosValidation->outputs[i] = new double[pDatosValidation->nOfOutputs];
		}
			


		//Reservamos memoria para entrTrain
		double** entrTrain=new double*[trainDataset->nOfPatterns-pDatosValidation->nOfPatterns];
		
		for(int i = 0; i<trainDataset->nOfPatterns-pDatosValidation->nOfPatterns; i++)
		{
			entrTrain[i] = new double[trainDataset->nOfInputs];
		}
			

		//Reservamos memoria para saliTrain
		double** saliTrain=new double*[trainDataset->nOfPatterns-pDatosValidation->nOfPatterns];


		for(int i=0; i<trainDataset->nOfPatterns-pDatosValidation->nOfPatterns; i++)
		{
			saliTrain[i] = new double[trainDataset->nOfOutputs];
		}
			

		sort(choosenVector, choosenVector+pDatosValidation->nOfPatterns);

		for(int i=0,j=0,k=0; i<trainDataset->nOfPatterns; i++){
			
			if(i==choosenVector[j])
			{
				pDatosValidation->inputs[j] = trainDataset->inputs[i];
				pDatosValidation->outputs[j] = trainDataset->outputs[i];
				j++;
			}
			else
			{
				entrTrain[k] = trainDataset->inputs[i];
				saliTrain[i] = trainDataset->outputs[i];
				k++;
			}
		}
			
		trainDataset->nOfPatterns = trainDataset->nOfPatterns - pDatosValidation->nOfPatterns;
		trainDataset->outputs = saliTrain;
		trainDataset->inputs = entrTrain;
	}


	// Learning
	do {

		trainOnline(trainDataset);
		double trainError = test(trainDataset);
		
		if(validationRatio > 0 && validationRatio < 1)
		{
			validationError = test(pDatosValidation);
			
			if(countTrain==0 || validationError < minValidationError)
			{
			
				minValidationError = validationError;
				iterWithoutImprovingValidation = 0;
			}
			else if( (validationError-minValidationError) < 0.00001)
			{
				iterWithoutImprovingValidation = 0;
			}
			else{iterWithoutImprovingValidation++;}
		}
		
		if(countTrain==0 || trainError < minTrainError)
		{
			minTrainError = trainError;
			copyWeights();
			iterWithoutImproving = 0;
		}
		else if( (trainError-minTrainError) < 0.00001)
			iterWithoutImproving = 0;
		else
		{
			iterWithoutImproving++;
			std::cout<<"It nº " <<iterWithoutImproving<<" sin mejorar."<<std::endl;

		}
			
		if(iterWithoutImproving==50)
		{
			cout << "Salida porque no mejora el entrenamiento!!"<< endl;
			restoreWeights();
			countTrain = maxiter;
		}
		
		if(iterWithoutImprovingValidation>=50)
		{
			cout << "Salida porque no mejora el error de validación!!"<< endl;
			restoreWeights();
			countTrain = maxiter;
		}
		
		countTrain++;

		// Check validation stopping condition and force it
		// BE CAREFUL: in this case, we have to save the last validation error, not the minimum one
		// Apart from this, the way the stopping condition is checked is the same than that
		// applied for the training set

		cout << "Iteración " << countTrain << "\t Error de entrenamiento: " << trainError << "\t Error de validación: " << validationError << endl;

	} while ( countTrain<maxiter );

	cout << "PESOS DE LA RED" << endl;
	cout << "===============" << endl;
	printNetwork();

	cout << "Salida Esperada Vs Salida Obtenida (test)" << endl;
	cout << "=========================================" << endl;
	
	for(int i=0; i<pDatosTest->nOfPatterns; i++){
		
		double* prediction = new double[pDatosTest->nOfOutputs];

		// Feed the inputs and propagate the values
		feedInputs(pDatosTest->inputs[i]);
		forwardPropagate();
		getOutputs(prediction);
		
		for(int j=0; j<pDatosTest->nOfOutputs; j++)
			cout << pDatosTest->outputs[i][j] << " -- " << prediction[j] << " ";
		
		cout << endl;
		delete[] prediction;

	}

	testError = test(pDatosTest);

	std::cout<<"Error test : "<<testError<<std::endl;
	std::cout<<"Error train : "<<minTrainError<<std::endl;

	*errorTest=testError;
	*errorTrain=minTrainError;

}

// Optional Kaggle: Save the model weights in a textfile
bool MultilayerPerceptron::saveWeights(const char * archivo)
{
	// Object for writing the file
	ofstream f(archivo);

	if(!f.is_open())
		return false;

	// Write the number of layers and the number of layers in every layer
	f << nOfLayers;

	for(int i = 0; i < nOfLayers; i++)
		f << " " << layers[i].nOfNeurons;
	f << endl;

	// Write the weight matrix of every layer
	for(int i = 1; i < nOfLayers; i++)
		for(int j = 0; j < layers[i].nOfNeurons; j++)
			for(int k = 0; k < layers[i-1].nOfNeurons + 1; k++)
				f << layers[i].neurons[j].w[k] << " ";

	f.close();

	return true;

}


// Optional Kaggle: Load the model weights from a textfile
bool MultilayerPerceptron::readWeights(const char * archivo)
{
	// Object for reading a file
	ifstream f(archivo);

	if(!f.is_open())
		return false;

	// Number of layers and number of neurons in every layer
	int nl;
	int *npl;

	// Read number of layers
	f >> nl;

	npl = new int[nl];

	// Read number of neurons in every layer
	for(int i = 0; i < nl; i++)
		f >> npl[i];

	// Initialize vectors and data structures
	initialize(nl, npl);

	// Read weights
	for(int i = 1; i < nOfLayers; i++)
		for(int j = 0; j < layers[i].nOfNeurons; j++)
			for(int k = 0; k < layers[i-1].nOfNeurons + 1; k++)
				f >> layers[i].neurons[j].w[k];

	f.close();
	delete[] npl;

	return true;
}
